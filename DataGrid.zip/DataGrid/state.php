<?php
include 'includes/database.php';

$data='';

   $state="select state_name,state_id from countries_state where country_id='".$_POST['country']."' order by state_name asc";
    $ptr_state=mysqli_query($con,$state);
     $data .='<select name="state" id="state" required class="form-control">';
    $data .='<option value="">--Select State--</option>';

while($fetch_state=mysqli_fetch_array($ptr_state,MYSQLI_ASSOC))
{
    
    $data .=' <option value="'.$fetch_state['state_id'].'">'.$fetch_state['state_name'].'</option>';
    
}
$data .='</select>';



 echo $data;
?>