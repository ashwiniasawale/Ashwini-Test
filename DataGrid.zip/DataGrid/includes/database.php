<?php

date_default_timezone_set('Asia/Kolkata');
$servername = "localhost";
$username = "root";
$password = "";
$database="family_details";

// Create connection
$con = new mysqli($servername, $username, $password,$database);

// Check connection
if (!$con) {
  die("Connection failed: " . $con->connect_error);
}else{
   // echo "Connected successfully";
}
//define('BASE_URL', 'http://localhost/DataGrid/');
$base_url='http://localhost/DataGrid/';
?>