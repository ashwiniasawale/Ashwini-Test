<?php
include 'includes/database.php';

$data='';

     $country="select country_name,country_id from countries  order by country_name asc";
    $ptr_country=mysqli_query($con,$country);


$data .='<option value="">--Select Country--</option>';

while($fetch_country=mysqli_fetch_array($ptr_country,MYSQLI_ASSOC))
{
    
    $data .=' <option value="'.$fetch_country['country_id'].'">'.$fetch_country['country_name'].'</option>';
    
}
 echo $data;
?>