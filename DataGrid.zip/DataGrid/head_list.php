<?php 

session_start();

include 'includes/database.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="assets/files/bootstrap.min.css">
  <script src="assets/files/jquery.min.js"></script>

  <link rel="stylesheet" href="assets/files/jquery-ui.css">
<script src="assets/files/jquery-1.12.4.js"></script>
<script src="assets/files/jquery-ui.js"></script>
  <script src="assets/files/bootstrap.min.js"></script>
  </head>
<body>

<div class="container">
<div class="row">
        <div class="col-lg-6"> <h4>Head List</h4></div>
        <div class="col-lg-6"><a href="<?php echo $base_url; ?>" style="float:right;" class="btn btn-primary">Add Family Details</a></div>
       
    
   </div>
  <?php if(isset($_SESSION['msg']))
  { ?>
  <div class="alert alert-success" role="alert">
  <?php echo $_SESSION['msg'];
unset($_SESSION['msg']); ?>
</div>
<?php } ?>
   
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Mobile</th>
        <th>Member Count</th>
      </tr>
    </thead>
    <tbody>
        <?php 
        $get_list="select family_head_id,first_name,last_name,mobile from family_head";
        $ptr_list=mysqli_query($con,$get_list);
         while($fetch_list=mysqli_fetch_array($ptr_list,MYSQLI_ASSOC))
         {
              $get_count="select count(family_member_id) as count from family_member where family_head_id='".$fetch_list['family_head_id']."'";
             $ptr_count=mysqli_query($con,$get_count);
             $fetch_count=mysqli_fetch_array($ptr_count,MYSQLI_ASSOC);
             ?>
              <tr>
        <td><?php echo $fetch_list['first_name']; ?></td>
        <td><?php echo $fetch_list['last_name']; ?></td>
        <td><?php echo $fetch_list['mobile']; ?></td>
        
        <td><a href="view_family_details?family_head_id=<?php echo $fetch_list['family_head_id']; ?>"><?php echo $fetch_count['count']; ?></a></td>
      </tr>
        <?php }
        ?>
    
    </tbody>
  </table>
</div>

</body>
</html>
