<script>
  

    $(function() {
  $( ".wedding_date" ).datepicker({  maxDate: 0 ,changeMonth: true,
    changeYear: true });
  $( ".member_birth_date" ).datepicker({  maxDate: 0 ,changeMonth: true,
    changeYear: true, yearRange: "-100Y:-0Y"  });
});
var date = new Date();
date.setFullYear(date.getFullYear() - 21)
$(".birth_date").datepicker({
    dateFormat: "mm-dd-yy",
    //maxDate: date,
    changeYear: true,
    changeMonth: true,
    yearRange: "-100Y:-20Y"
    
});
    check_status();
    check_member_status(0);
    check_country();
        //get_state();
        function check_member_status(i)
        {
           
             var member_marital_status=document.getElementById('member_marital_status'+i).value;
             //alert(member_marital_status)
            if(member_marital_status=='Yes')
            {
                document.getElementById('show_member_marital_status'+i).style.display='block';
            }else{
                document.getElementById('show_member_marital_status'+i).style.display='none';
                document.getElementById('member_wedding_date'+i).value='';
        
            }
           
        }
        function check_status()
        {
            var marital_status=document.getElementById('marital_status').value;
          
            if(marital_status=='Yes')
            {
                document.getElementById('show_marital_status').style.display='block';
            }else{
                document.getElementById('show_marital_status').style.display='none';
                document.getElementById('wedding_date').value='';
        
            }
        }
        function check_country() {
            $.ajax({
                url: 'countries',
                type: 'post',

                data: {
                   
                },
                success: function (data) {
                    // alert(data)
                    $('#country').empty();
                    document.getElementById('country').innerHTML = data;
                }
            });
        }
        function get_state() {
           
            var country = document.getElementById('country').value;
            $.ajax({
                url: 'state',
                type: 'post',

                data: {
                   
                    country: country
                },
                success: function (data) {
                   //  alert(data)
                    $('#show-state').empty();
                    document.getElementById('show-state').innerHTML = data;
                }
            });
        }

    </script>