<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="assets/files/jquery.min.js"></script>

  <link rel="stylesheet" href="assets/files/jquery-ui.css">
<script src="assets/files/jquery-1.12.4.js"></script>
<script src="assets/files/jquery-ui.js"></script>
  <script src="assets/files/bootstrap.min.js"></script>
  
</head>
<body>

  
<?php 

include 'includes/database.php';
if($_GET['family_head_id'])
{
   $select_head="select family_head.family_head_id,family_head.first_name,family_head.last_name,family_head.birth_date,family_head.mobile,family_head.address,family_head.photo,countries.country_name,countries_state.state_name,family_head.city,family_head.pincode,family_head.marital_status,family_head.wedding_date,family_head.hobbie,family_head.created_date from family_head,countries,countries_state where family_head.country_id=countries.country_id and family_head.state_id=countries_state.state_id and family_head.family_head_id='".$_GET['family_head_id']."'";

   $ptr_head=mysqli_query($con,$select_head);
   $num_rows=mysqli_num_rows($ptr_head);
   if($num_rows>0)
   {
       $fetch_head=mysqli_fetch_array($ptr_head);
       ?>
       
    <div class="container">
    <div class="row">
        <div class="col-lg-6"> <h4>Head Details</h4></div>
        <div class="col-lg-6"><a href="head_list" style="float:right;" class="btn btn-primary">View List</a></div>
       
    
   </div>
    <table class="table ">
    <tbody>
      <tr>
    
        <td><strong>Firstname:</strong> <?php echo $fetch_head['first_name']; ?></td>
        
        <td><strong>Lastname:</strong> <?php echo $fetch_head['last_name']; ?></td>
        
        <td><strong>Mobile:</strong> <?php echo $fetch_head['mobile']; ?></td>
      </tr>
      <tr>
        
        <td><strong>Birth Date:</strong> <?php echo $fetch_head['birth_date']; ?></td>
        
        <td><strong>Address:</strong><?php echo $fetch_head['address']; ?></td>
        
        <td><strong>Photo:</strong> <img style="width:50px;height:50px;" src="assets/photo/<?php echo $fetch_head['photo']; ?>"></td>
      </tr>
      <tr>
    
        <td><strong>Country:</strong> <?php echo $fetch_head['country_name']; ?></td>
        
        <td><strong>State:</strong> <?php echo $fetch_head['state_name']; ?></td>
        
        <td><strong>City:</strong> <?php echo $fetch_head['city']; ?></td>
    </tr>
    <tr>
        
        <td><strong>Marital Status:</strong> <?php echo $fetch_head['marital_status']; ?></td>
        
        <td><strong>Wedding Date:</strong> <?php echo $fetch_head['wedding_date']; ?></td>
        
        <td><strong>Hobbies:</strong> <?php echo $fetch_head['hobbie']; ?></td>
    </tr>
   </tbody>
    
  </table>

  <h4>Family Members</h4>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Birth Date</th>
        <th>Marital Status</th>
        <th>Wedding Date</th>
        <th>Photo</th>
      </tr>
    </thead>
    <tbody>
        <?php 
         $get_list="select member_name,member_birth_date,member_marital_status,member_wedding_date,member_photo from family_member where family_head_id='".$fetch_head['family_head_id']."'";
        $ptr_list=mysqli_query($con,$get_list);
         while($fetch_list=mysqli_fetch_array($ptr_list,MYSQLI_ASSOC))
         {
            
             ?>
              <tr>
        <td><?php echo $fetch_list['member_name']; ?></td>
        <td><?php echo $fetch_list['member_birth_date']; ?></td>
        <td><?php echo $fetch_list['member_marital_status']; ?></td>
        <td><?php echo $fetch_list['member_wedding_date']; ?></td>
        
        <td><img style="width:50px;height:50px;" src="assets/photo/<?php echo $fetch_list['member_photo']; ?>"></td>
      </tr>
        <?php }
        ?>
    
    </tbody>
  </table>
   </div>
       <?php 
   }
}
?>
</body>
</html>