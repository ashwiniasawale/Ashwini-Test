<!DOCTYPE html>
<html lang="en">
<head>
  <title>Family Details</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="assets/files/jquery.min.js"></script>

  <link rel="stylesheet" href="assets/files/jquery-ui.css">
<script src="assets/files/jquery-1.12.4.js"></script>
<script src="assets/files/jquery-ui.js"></script>
  <script src="assets/files/bootstrap.min.js"></script>
  
  <?php include 'includes/database.php'; ?>
  <style>
        .loader {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background: url('assets/images/loader2.gif') 50% 50% no-repeat rgb(249, 249, 249);
            opacity: .8;
        }
    </style>
</head>
<body>


<div class="container">
<div class="loader" style="display:none" id="loader"></div>
<div class="row">
        <div class="col-lg-6"> <h4><u>Family Head Details</u></h4></div>
        <div class="col-lg-6"><a href="head_list" style="float:right;" class="btn btn-primary">View List</a></div>
       
    
   </div>
  <form  id="Insertform" enctype="multipart/form-data" method="post">
    <div class="row">
     <div class="col-lg-4"> 
        <div class="form-group">
        <label for="first_name">First Name:</label>
        <input type="text" class="form-control" id="first_name" placeholder="Enter Name" required maxlength="32" name="first_name">
        </div>
    </div>
    <div class="col-lg-4"> 
        <div class="form-group">
        <label for="pwd">Last Name:</label>
        <input type="text" class="form-control" id="last_name" placeholder="Enter Surname" required maxlength="32" name="last_name">
        </div>
    </div>
    <div class="col-lg-4"> 
        <div class="form-group">
        <label for="pwd">Birth Date:</label>
        <input type="text" class="form-control birth_date" required id="birth_date"  placeholder="Date" name="birth_date">
        
    </div>
    </div>
   </div>
<div class="row">
<div class="col-lg-4"> 
    <div class="form-group">
      <label for="first_name">Mobile Number:</label>
      <input type="text" class="form-control" required id="mobile" maxlength="10" pattern="\d{10}" title="Please enter exactly 10 digits" placeholder="Enter Mobile" name="mobile" required>
    </div>
</div> 
<div class="col-lg-4"> 
    <div class="form-group">
      <label for="pwd">Address:</label>
      <textarea  class="form-control" id="address" placeholder="Enter Address" name="address" required></textarea>
    </div>
</div>
<div class="col-lg-4"> 
    <div class="form-group">
      <label for="pwd">Photo:</label>
      <input type="file"  class="form-control" required accept=".jpg, .jpeg, .png"  id="photo" placeholder="Enter Address" name="photo">
        </div>
</div>
</div>
<br>
<div class="row">
<div class="col-lg-4"> 
    <div class="form-group">
      <label>Country:</label>
      
        <select name="country" id="country" onchange="get_state();" class="form-control" required>
          
        </select>
    </div>
</div>
<div class="col-lg-4"> 
    <div class="form-group">
      <label for="pwd">State:</label>
      <div id="show-state">

        </div>
    </div>
</div>
<div class="col-lg-4"> 
    <div class="form-group">
      <label for="pwd">City:</label>
      <input type="text" class="form-control" placeholder="City"
                                                            required name="city" id="city">
    </div>
</div>
</div>
<div class="row">
<div class="col-lg-4"> 
    <div class="form-group">
      <label for="pwd">Pincode:</label>
      <input type="text" class="form-control" placeholder="Pincode" title="6 digit" maxlength="6" pattern="\d{6}"
                                                            required name="pincode" id="pincode">
    </div>
</div>

<div class="col-lg-4"> 
    <div class="form-group">
      <label>Marital Status:</label>
      
        <select name="marital_status" id="marital_status" onchange="check_status();"  class="form-control" required>
          
            <option value="Yes">Yes</option>
            <option value="No">No</option>
        </select>
    </div>
</div>
<div class="col-lg-4" id="show_marital_status" style="display:block;"> 
    <div class="form-group">
      <label for="pwd">Wedding Date:</label>
      <input type="text" class="form-control wedding_date" placeholder="wedding_date"
                                                             name="wedding_date" id="wedding_date">
    </div>
</div>
</div>

<hr>
<div class="field_wrapper">
    <div class="row">
    <label for="pwd">Hobbies:</label>

        <input style="width:25%" type="text" name="hobbie[]" required class="form-control" value=""/>
       
    </div><br>
    
</div>

<a href="javascript:void(0);" class="add_button"  title="Add field">Add</a>

<hr>
<h4><u>Family Members Details</u></h4>
<div class="field_wrapper1">
    <div class="row">
        <div class="col-lg-4">
          <label >Name:</label>
            <input  type="text" name="member_name[]"  class="form-control"  required value=""/>
        </div>

        <div class="col-lg-4"> 
          <label for="pwd">Birth Date:</label>
          <input type="date"   required class="form-control  "  id="member_birth_date0" placeholder="Date" name="member_birth_date[]">
        </div>

        <div class="col-lg-4"> 
          <label>Marital Status:</label>
            <select name="member_marital_status[]"  onchange="check_member_status(0)" id="member_marital_status0"  class="form-control" required>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
            </select>
        </div>
        <div class="col-lg-4" id="show_member_marital_status0" style="display:block;"> 
           <label>Wedding Date:</label>
            <input type="date" class="form-control" placeholder="member_wedding_date"  name="member_wedding_date[]" id="member_wedding_date0">
          
        </div>
        <div class="col-lg-4"> 
   
            <label for="pwd">Photo:</label>
            <input type="file"  class="form-control" id="member_photo0" placeholder="Enter " required accept=".jpg, .jpeg, .png"  name="member_photo[]">
       
        </div>

    </div><br>
    
</div>
<br>
    <a href="javascript:void(0);" class="btn btn-primary member_add_button"  title="Add field">Add More</a>
<div>
</br>
    <button type="submit" name="submit" class="btn btn-success">Submit</button>
</div>
</br>
  </form>
</div>

</body>
<?php  include 'condition.php'; ?>
<script>
    
$(document).ready(function(){
    var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var x = 1; //Initial field counter is 1
    
    // Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            var fieldHTML = '<div class="row"><input style="width:25%" type="text" class="form-control" name="hobbie[]" value=""/><br><a href="javascript:void(0);" class="remove_button btn btn-danger">Remove</a></div>'; //New input field html 
   
          
            $(wrapper).append(fieldHTML); //Add field html
            x++; //Increase field counter
        }else{
            alert('A maximum of '+maxField+' fields are allowed to be added. ');
        }
    });
    
    // Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrease field counter
    });



    var maxField1 = 10; //Input fields increment limitation
    var addButton1 = $('.member_add_button'); //Add button selector
    var wrapper1 = $('.field_wrapper1'); //Input field wrapper
    var y = 1; //Initial field counter is 1
    
   
    // Once add button is clicked
    $(addButton1).click(function(){
       
        //Check maximum number of input fields
        if(y < maxField1){ 
         
          var fieldHTML1='<hr><div class="row"><div class="col-lg-4"><label >Name:</label>';

                fieldHTML1 +='<input  type="text" name="member_name[]"  class="form-control" value=""/ required></div>';
                fieldHTML1 +='   <div class="col-lg-4"> ';

                fieldHTML1 +='<label for="pwd">Birth Date:</label>';
                fieldHTML1 +=' <input type="date" class="form-control member_birth_date" id="member_birth_date'+y+'" placeholder="Date" name="member_birth_date[]" required>';

                fieldHTML1 +='</div>';

                fieldHTML1 +='   <div class="col-lg-4">';

                fieldHTML1 +='<label>Marital Status:</label>';
                        
                fieldHTML1 +='<select name="member_marital_status[]"  onchange="check_member_status('+y+')" id="member_marital_status'+y+'"  class="form-control" required>';
                fieldHTML1 +='<option value="Yes">Yes</option>';
                fieldHTML1 +='<option value="No">No</option>';
                fieldHTML1 +='</select>';
                fieldHTML1 +='</div>';
                fieldHTML1 +='<div class="col-lg-4" id="show_member_marital_status'+y+'" style="display:block;">';
                fieldHTML1 +='<label for="pwd">Wedding Date:</label>';
                fieldHTML1 +='<input type="date" class="form-control "   placeholder="member_wedding_date"  name="member_wedding_date[]" id="member_wedding_date'+y+'">';
                    
                fieldHTML1 +='   </div>';
                fieldHTML1 +='   <div class="col-lg-4"> ';

                fieldHTML1 +='<label for="pwd">Photo:</label>'
                fieldHTML1 +='<input type="file"  class="form-control" id="member_photo'+y+'" required accept=".jpg, .jpeg, .png"  placeholder="Enter " name="member_photo[]">';
                
                fieldHTML1 +='   </div><br><a href="javascript:void(0);" class="member_remove_button">Remove</a>';

                fieldHTML1 +='</div>';

            $(wrapper1).append(fieldHTML1); //Add field html
            y++;
        }else{
            alert('A maximum of '+maxField1+' fields are allowed to be added. ');
        }
    });
    
    // Once remove button is clicked
    $(wrapper1).on('click', '.member_remove_button', function(e1){
        e1.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        y--; //Decrease field counter
    });
});

$("#Insertform").on('submit',(function(e) {
  e.preventDefault();
  document.getElementById('loader').style.display='block'; 
      
  $.ajax({
         url: "family",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend : function()
   {
    //$("#preview").fadeOut();
   // $("#err").fadeOut();
   },
   success: function(data)
      {
         
   var html=data.split("####");
  
   if(html[0].trim()=='error')
   {
    $(".loader").fadeOut("slow");
       alert(html[1])
   }else if(html[0].trim()=='success'){
    $(".loader").fadeOut("slow");
    window.location = html[1];
   }
      },
     error: function(e) 
      {
   
      }          
    });
 }));

 
</script>
</html>
