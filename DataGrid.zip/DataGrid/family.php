<?php 
session_start();

include 'includes/database.php';

if($_POST['mobile'] && $_POST['first_name'])
{
   
    $check_mobile="select mobile from family_head where mobile='".$_POST['mobile']."'";
$ptr_mobile=mysqli_query($con,$check_mobile);
$total_mobile=mysqli_num_rows($ptr_mobile);
if($total_mobile>0)
{
    $status='error';
    $message="Mobile Id Registred";
    echo $status.'####'.$message;
  
}else
{
    $uuid=sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
    mt_rand(0, 0xffff), mt_rand(0, 0xffff),
    mt_rand(0, 0xffff),
    mt_rand(0, 0x0fff) | 0x4000,
    mt_rand(0, 0x3fff) | 0x8000,
    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
  );

  if($_FILES['photo']['name']=='')
  {
      $photo='';
  }else{
      $photo=time().$_FILES['photo']['name'];
  }
 
  $targes='./assets/photo/'.$photo;
  move_uploaded_file($_FILES['photo']['tmp_name'], $targes);
  $hobb=implode(", ",$_POST['hobbie']);
 $insert_head="insert into family_head(family_head_id,first_name,last_name,birth_date,mobile,address,photo,country_id,state_id,city,pincode,marital_status,wedding_date,hobbie)
values('".$uuid."','".$_POST['first_name']."','".$_POST['last_name']."','".$_POST['birth_date']."','".$_POST['mobile']."',".json_encode($_POST['address']).",'".$photo."','".$_POST['country']."','".$_POST['state']."',".json_encode($_POST['city']).",'".$_POST['pincode']."','".$_POST['marital_status']."','".$_POST['wedding_date']."','".$hobb."')";
$ptr_reg=mysqli_query($con,$insert_head);
if($ptr_reg)
{
   // echo count($_POST['member_name']);
 for($i=0;$i<count($_POST['member_name']);$i++)
 {
    $mem_uuid=sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
    mt_rand(0, 0xffff), mt_rand(0, 0xffff),
    mt_rand(0, 0xffff),
    mt_rand(0, 0x0fff) | 0x4000,
    mt_rand(0, 0x3fff) | 0x8000,
    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
  );
  if($_FILES['photo']['name'][$i]=='')
   {
       $member_photo='';
   }else{
       $member_photo=time().$_FILES['member_photo']['name'][$i];
   }
   $targes='./assets/photo/'.$member_photo;
   move_uploaded_file($_FILES['member_photo']['tmp_name'][$i], $targes);
       $insert_member="insert into family_member(family_member_id,family_head_id,member_name,member_birth_date,member_marital_status,member_wedding_date,member_photo)
      values('".$mem_uuid."','".$uuid."','".$_POST['member_name'][$i]."','".$_POST['member_birth_date'][$i]."','".$_POST['member_marital_status'][$i]."','".$_POST['member_wedding_date'][$i]."','".$member_photo."')";
      $ptr_member=mysqli_query($con,$insert_member);
    }
    $_SESSION['msg']="Family Details Added";
   // header("location:head_list");
   
}
$status="success";
$message=$base_url.'head_list';
echo $status.'####'.$message;
}

}
?>